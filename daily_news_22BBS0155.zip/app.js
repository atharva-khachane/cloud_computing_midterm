const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

// Data for our creative endpoints
const funFacts = [
    "A single cloud can weigh more than 1 million pounds.",
    "A group of flamingos is called a 'flamboyance'.",
    "The creator of the Pringles can is now buried in one.",
    "There are more trees on Earth than stars in the Milky Way galaxy.",
    "Octopuses have three hearts."
];

// Simple inline CSS for styling
const styles = `
    <style>
        body { font-family: Arial, sans-serif; background-color: #f0f2f5; margin: 0; padding: 20px; text-align: center; }
        .container { max-width: 600px; margin: 40px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h1 { color: #333; }
        p { color: #555; font-size: 1.2em; }
        .button-nav { margin-top: 30px; }
        .button { display: inline-block; text-decoration: none; background-color: #007bff; color: white; padding: 15px 25px; border-radius: 5px; margin: 5px; font-weight: bold; transition: background-color 0.3s; }
        .button:hover { background-color: #0056b3; }
        img.image { max-width: 100%; border-radius: 10px; margin-top: 20px; }
    </style>
`;

// 1. Home Page Endpoint
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Daily Times</title>
            ${styles}
        </head>
        <body>
            <div class="container">
                <h1>Welcome to Daily Times!</h1>
                <p>Greetings from Vellore! Here's your dose of fun for the day</p>
                <div class="button-nav">
                    <a href="/fact" class="button">Get a Fun Fact</a>
                    <a href="/image" class="button">See an Inspiring Image</a>
                </div>
            </div>
        </body>
        </html>
    `);
});

// 2. Fact Page Endpoint
app.get('/fact', (req, res) => {
    const randomFact = funFacts[Math.floor(Math.random() * funFacts.length)];
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Fun Fact</title>
            ${styles}
        </head>
        <body>
            <div class="container">
                <h1>Here's a Fun Fact!</h1>
                <p>${randomFact}</p>
                <div class="button-nav">
                    <a href="/" class="button">Back to Home</a>
                </div>
            </div>
        </body>
        </html>
    `);
});

// 3. Image Page Endpoint
app.get('/image', (req, res) => {
    // We use Unsplash Source for random high-quality images.
    const imageUrl = 'https://picsum.photos/800/600';
    res.send(`  
        <!DOCTYPE html>
        <html>
        <head>
            <title>An Image</title>
            ${styles}
        </head>
        <body>
            <div class="container">
                <h1>An Image</h1>
                <img src="${imageUrl}" alt="Image" class="image">
                <div class="button-nav">
                    <a href="/" class="button">Back to Home</a>
                </div>
            </div>
        </body>
        </html>
    `);
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});